﻿/*
 * PLUGIN EDIT
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.EditTrackers 		= "Redigera torrent...";
 theUILang.EditTorrentProperties	= "Torrentegenskaper";
 theUILang.errorAddTorrent		= "Fel när torrentfilen lades till";
 theUILang.errorWriteTorrent		= "Fel vid skrivning till torrentfil";
 theUILang.errorReadTorrent		= "Fel vid läsning av torrentfil";
 theUILang.cantFindTorrent		= "Källfil (.torrent) för denna nedladdning kunde inte hittas.."

thePlugins.get("edit").langLoaded();
