﻿/*
 * PLUGIN DATADIR
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.DataDir		= "保存到";
 theUILang.DataDirMove		= "移动数据文件";
 theUILang.datadirDlgCaption	= "Torrent 数据目录";
 theUILang.datadirDirNotFound	= "DataDir plugin: Invalid directory";
 theUILang.datadirSetDirFail	= "DataDir plugin: Operation fail";

thePlugins.get("datadir").langLoaded();