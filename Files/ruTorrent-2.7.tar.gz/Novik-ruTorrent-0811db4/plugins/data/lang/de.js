﻿/*
 * PLUGIN DATA
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.getData		= "Herunterladen";
 theUILang.cantAccessData	= "Webserver-Benutzer kann nicht auf die Daten dieses Torrents zugreifen.";

thePlugins.get("data").langLoaded();