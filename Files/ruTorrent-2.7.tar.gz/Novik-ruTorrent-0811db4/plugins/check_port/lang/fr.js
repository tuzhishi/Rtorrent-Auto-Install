﻿/*
 * PLUGIN CHECK_PORT
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.checkPort		= "Vérification du port";
 theUILang.portStatus		= [
 				  "Statut du port inconnu", 
 				  "Le port est fermé",
 				  "Le port est ouvert"
 				  ];

thePlugins.get("check_port").langLoaded();