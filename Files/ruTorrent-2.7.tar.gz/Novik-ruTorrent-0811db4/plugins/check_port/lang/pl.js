﻿/*
 * PLUGIN CHECK_PORT
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.checkPort		= "Sprawdź przekierowanie Portu/Portów";
 theUILang.portStatus		= [
 				  "Port status nieznany",
 				  "Port zamknięty",
 				  "Port otwarty"
 				  ];

thePlugins.get("check_port").langLoaded();