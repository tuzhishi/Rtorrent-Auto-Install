﻿/*
 * PLUGIN DISKSPACE
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.diskNotification = "Προειδοποίηση! Ο δίσκος είναι πλήρης. Το rTorrent μπορεί να μην λειτουργεί σωστά, και δεν θα γίνεται λήψη δεδομένων μέχρι να ελευθερώσετε χώρο στο δίσκο.";

thePlugins.get("diskspace").langLoaded();