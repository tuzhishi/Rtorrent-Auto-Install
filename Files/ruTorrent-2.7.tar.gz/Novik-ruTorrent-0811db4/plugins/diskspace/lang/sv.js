﻿/*
 * PLUGIN DISKSPACE
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.diskNotification = "Varning! Disken är full. rTorrent kan inte köras korrekt och ingen data kommer att laddas ner förrän du frigör diskutrymme.";

thePlugins.get("diskspace").langLoaded();
