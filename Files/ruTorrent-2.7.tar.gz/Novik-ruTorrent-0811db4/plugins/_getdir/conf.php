<?php
	$checkUserPermissions 	= true;	
