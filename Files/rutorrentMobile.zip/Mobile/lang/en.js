﻿/**********************************************************
 * rutorrent Mobile: A mobile rutorrent plugin
 * Author: Carlos Jimenez Delgado (mail@carlosjdelgado.com)
 * License: GNU General Public License
 **********************************************************/
theUILang.areYouShure = 'Do you really want to remove this torrent?';

theUILang.Date = 		'Date';
theUILang.Progress = 	'Progress';
theUILang.Ascending = 	'Ascending';
theUILang.Descending = 	'Descending';

theUILang.Configuration = 	'Configuration';

theUILang.Menu = 	'Menu';
theUILang.Filter = 	'Filter';

theUILang.Back = 	'Back';
theUILang.Ok = 		'Accept';

theUILang.DownloadLimit = 	'Download limit';
theUILang.UploadLimit =		'Upload limit';

theUILang.InserUrlLabel =	'Set torrent file URL';

theUILang.Actions =	'Actions';

mobile.onLangLoaded();
