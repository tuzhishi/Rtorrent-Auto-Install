﻿/**********************************************************
 * rutorrent Mobile: A mobile rutorrent plugin
 * Author: Carlos Jimenez Delgado (mail@carlosjdelgado.com)
 * License: GNU General Public License
 **********************************************************/

theUILang.areYouShure = 'Voulez-vous vraiment effacer le torrent selectionné ?';

theUILang.Date = 		'Date';
theUILang.Progress = 	'Etat';
theUILang.Ascending = 	'Ascendant';
theUILang.Descending = 	'Descendant';

theUILang.Configuration = 	'Configuration';

theUILang.Menu = 	'Menu';
theUILang.Filter = 	'Filtre';

theUILang.Back = 	'Retour';
theUILang.Ok = 		'Valider';

theUILang.DownloadLimit = 	'Limite de réception';
theUILang.UploadLimit =		'Limite d\'envoi';

theUILang.InserUrlLabel =	'Entrez l\'URL du fichier torrent';

theUILang.Actions =	'Actions';

mobile.onLangLoaded();
