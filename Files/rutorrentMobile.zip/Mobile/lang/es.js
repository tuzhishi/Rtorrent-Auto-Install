﻿/**********************************************************
 * rutorrent Mobile: A mobile rutorrent plugin
 * Author: Carlos Jimenez Delgado (mail@carlosjdelgado.com)
 * License: GNU General Public License
 **********************************************************/
theUILang.areYouShure = 'Realmente quieres borrar el torrent?';

theUILang.Date = 		'Fecha';
theUILang.Progress = 	'Progreso';
theUILang.Ascending = 	'Ascendente';
theUILang.Descending = 	'Descendente';

theUILang.Configuration = 	'Configuración';

theUILang.Menu = 	'Menu';
theUILang.Filter = 	'Filtro';

theUILang.Back = 	'Volver';
theUILang.Ok = 		'Aceptar';

theUILang.DownloadLimit = 	'Velocidad límite de bajada';
theUILang.UploadLimit =		'Velocidad límite de subida';

theUILang.InserUrlLabel =	'Introduce la URL del fichero torrent';

theUILang.Actions =	'Acciones';

mobile.onLangLoaded();