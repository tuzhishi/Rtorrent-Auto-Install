rutorrentMobile
===============
rutorrentMobile is a rutorrent plugin that use jquery mobile for offer the best user experience by rutorrent in mobile devices such tablets and smartphones.

features of plugin are there:
* View progress and status of all your downloads in a list
* You can add a new torrent by entering an url with the .torrent file
* If you have too many downloads you can filter and order the list
* Can delete, pause or stop a download  or init a paused or stopped download.
* You can configure speed limits of the system
* Details of a download item just tapping it

Version
----
0.1

Installation
--------------
* Get the plugins files and copy into plugins rutorrent directory
* Open rutorrent from an smartphone or tablet and enjoy it.

Translate
------------
As you can see I am not very good in languages, I need your help translating the plugin.
Now plugin are only translated to english and spanish, would great if you could push some changes in language files, for this purpose i created the translations branch.

License
----
GNU General Public License 3.0
