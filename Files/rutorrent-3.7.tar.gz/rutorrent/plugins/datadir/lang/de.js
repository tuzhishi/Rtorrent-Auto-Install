﻿/*
 * PLUGIN DATADIR
 *
 * German language file.
 *
 * Author:  Dario Rugani (kontakt@rugani.de)
 */

 theUILang.DataDir		= "Speichern unter";
 theUILang.DataDirMove		= "Verschiebe Daten";
 theUILang.datadirDlgCaption	= "Torrent Daten Verzeichnis";
 theUILang.datadirDirNotFound	= "DataDir plugin: Ungültiges Verzeichnis";
 theUILang.datadirSetDirFail	= "DataDir plugin: Operation fehlgeschlagen";

thePlugins.get("datadir").langLoaded();