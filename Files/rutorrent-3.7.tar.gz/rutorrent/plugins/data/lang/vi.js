﻿/*
 * PLUGIN DATA
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.getData		= "Lấy dữ liệu";
 theUILang.cantAccessData	= "Máy chủ Web không thể truy cập dữ liệu của torrent này.";

thePlugins.get("data").langLoaded();