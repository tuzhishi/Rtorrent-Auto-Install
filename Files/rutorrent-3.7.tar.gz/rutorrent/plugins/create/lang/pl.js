﻿/*
 * PLUGIN CREATE
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.mnu_create			= "Utwórz Torrent...";
 theUILang.CreateNewTorrent		= "Utwórz nowy plik Torrent";
 theUILang.SelectSource 		= "Wskaż źródło";
 theUILang.TorrentProperties		= "Właściwości Torrenta";
 theUILang.PieceSize			= "Rozmiar kawałka";
 theUILang.Other			= "Inne";
 theUILang.StartSeeding 		= "Rozpocznij seedowanie";
 theUILang.PrivateTorrent		= "Prywatny torrent";
 theUILang.CreateAndSaveAs		= "Utwórz i zapisz jako...";
 theUILang.BadTorrentData		= "Musisz wypełnić wszystkie wymagane pola!";
 theUILang.createExternalNotFound	= "Wtyczka Utwórz Torrent:  Serwer nie ma dostępu do zewnętrznej aplikacji. Wtyczka nie będzie działać.";
 theUILang.incorrectDirectory		= "Niepoprawny folder";
 theUILang.cantExecExternal		= "Nie można wykonać zewnętrznego programu";
 theUILang.createConsole		= "Konsola";
 theUILang.createErrors 		= "Błędy";
 theUILang.torrentSave			= "Zapisz";
 theUILang.torrentKill			= "Stop";
 theUILang.torrentKilled		= "Proces został zatrzymany.";
 theUILang.recentTrackers		= "Ostatnie trackery";
 thePlugins.get("create").langLoaded();
