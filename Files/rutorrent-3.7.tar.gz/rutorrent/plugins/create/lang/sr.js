﻿/*
 * PLUGIN CREATE
 *
 * Serbian language file.
 *
 * Author: Zoltan Csala (zcsala021 at gmail dot com)
 */

 theUILang.mnu_create			= "Направи торент ...";
 theUILang.CreateNewTorrent		= "Направи нови торент";
 theUILang.SelectSource 		= "Избор извора";
 theUILang.TorrentProperties		= "Сво?ства торента";
 theUILang.PieceSize			= "Величина парчета";
 theUILang.Other			= "Друго";
 theUILang.StartSeeding 		= "Почетак се?а?а";
 theUILang.PrivateTorrent		= "Приватни торент";
 theUILang.torrentCreate		= "Направи...";
 theUILang.BadTorrentData		= "Морате попунити сва обавезна по?а!";
 theUILang.createExternalNotFound	= "Креира?е додатка: Додатак не?е радити. Мрежни сервер не може да приступи екстерном програму";
 theUILang.incorrectDirectory		= "Incorrect directory";
 theUILang.cantExecExternal		= "Can't execute external program";
 theUILang.createConsole		= "Console";
 theUILang.createErrors 		= "Errors";
 theUILang.torrentSave			= "Save";
 theUILang.torrentKill			= "Stop";
 theUILang.torrentKilled		= "Process was stopped.";
 theUILang.recentTrackers		= "Recent trackers";

thePlugins.get("create").langLoaded();